<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center mt-4 mb-5">
        <div class="col-md-8">
            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-outline-secondary mb-3">← Назад</a>

            <div class="card p-4">
                <div class="d-flex align-items-center mb-4">
                    <?php if($user->avatar): ?>
                        <img src="<?php echo e(asset('storage/' . $user->avatar)); ?>" class="rounded-circle me-3" style="width: 80px; height: 80px; object-fit: cover;">
                    <?php else: ?>
                        <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white fw-bold me-3" style="width: 80px; height: 80px; font-size: 2rem;">
                            <?php echo e(mb_substr($user->name, 0, 1)); ?>

                        </div>
                    <?php endif; ?>
                    <div>
                        <h2 class="text-white mb-0"><?php echo e($user->name); ?></h2>
                        <?php if (isset($component)) { $__componentOriginal68a7f9b685e4c3855325d9cded0a12de = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68a7f9b685e4c3855325d9cded0a12de = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rating-badge','data' => ['rating' => $user->rating]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rating-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['rating' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user->rating)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68a7f9b685e4c3855325d9cded0a12de)): ?>
<?php $attributes = $__attributesOriginal68a7f9b685e4c3855325d9cded0a12de; ?>
<?php unset($__attributesOriginal68a7f9b685e4c3855325d9cded0a12de); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68a7f9b685e4c3855325d9cded0a12de)): ?>
<?php $component = $__componentOriginal68a7f9b685e4c3855325d9cded0a12de; ?>
<?php unset($__componentOriginal68a7f9b685e4c3855325d9cded0a12de); ?>
<?php endif; ?>
                    </div>
                </div>

                <!-- Статистика с подписями -->
                <h5 class="text-white mb-3">Статистика</h5>
                <div class="row text-center mb-4">
                    <div class="col-6 col-md-3 mb-2">
                        <div class="bg-dark rounded p-3 border border-secondary h-100 d-flex flex-column justify-content-center">
                            <h3 class="text-danger mb-1"><?php echo e($stats['lost_total']); ?></h3>
                            <small class="text-white" style="font-size: 0.65rem;">Потеряно</small>
                        </div>
                    </div>
                    <div class="col-6 col-md-3 mb-2">
                        <div class="bg-dark rounded p-3 border border-secondary h-100 d-flex flex-column justify-content-center">
                            <h3 class="text-success mb-1"><?php echo e($stats['found_and_returned']); ?></h3>
                            <small class="text-white" style="font-size: 0.65rem;">Нашел и вернул</small>
                        </div>
                    </div>
                    <div class="col-6 col-md-3 mb-2">
                        <div class="bg-dark rounded p-3 border border-secondary h-100 d-flex flex-column justify-content-center">
                            <h3 class="text-warning mb-1"><?php echo e($stats['returned_to_owner']); ?></h3>
                            <small class="text-white" style="font-size: 0.65rem;">Вернул хозяину</small>
                        </div>
                    </div>
                    <div class="col-6 col-md-3 mb-2">
                        <div class="bg-dark rounded p-3 border border-secondary h-100 d-flex flex-column justify-content-center">
                            <h3 class="text-info mb-1"><?php echo e($stats['returned_to_me']); ?></h3>
                            <small class="text-white" style="font-size: 0.65rem;">Вернули мне</small>
                        </div>
                    </div>
                </div>

                <hr class="border-secondary">

                <h5 class="text-white mb-3">Активные объявления</h5>
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $user->items()->where('status', 'active')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-6 mb-3">
                            <a href="<?php echo e(route('items.show', $item->id)); ?>" class="text-decoration-none">
                                <div class="card p-2">
                                    <h6 class="text-white mb-1"><?php echo e($item->title); ?></h6>
                                    <small class="<?php echo e($item->type === 'lost' ? 'text-danger' : 'text-success'); ?>">
                                        <?php echo e($item->type === 'lost' ? 'Потеряно' : 'Найдено'); ?>

                                    </small>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-muted">Нет активных объявлений.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\findback\resources\views/profile/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="row mt-4 mb-5">
        <div class="col-12">
            <h2 class="text-white mb-4">Найденные совпадения</h2>

            <?php if($matches->isEmpty()): ?>
                <div class="alert alert-secondary">Пока совпадений нет. Мы сообщим, если что-то найдется!</div>
            <?php else: ?>
                <div class="row">
                    <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 mb-4">
                            <div class="card p-4 border border-warning h-100 d-flex flex-column">
                                <h5 class="text-warning mb-3">✨ Возможное совпадение!</h5>

                                <div class="row text-center mb-3">
                                    <!-- Блок потерянной вещи (проверяем, есть ли она) -->
                                    <div class="col-6">
                                        <strong class="text-white d-block mb-2">Потеряно:</strong>
                                        <?php if($match->lostItem): ?>
                                            <?php if($match->lostItem->photo): ?>
                                                <img src="<?php echo e(asset('storage/' . $match->lostItem->photo)); ?>" class="img-fluid rounded mb-2" style="max-height: 150px; object-fit: cover;">
                                            <?php endif; ?>
                                            <p class="mb-1 text-white"><?php echo e($match->lostItem->title); ?></p>
                                            <small class="text-muted">
                                                <?php echo e($match->lostItem->location->city ?? ''); ?>, <?php echo e($match->lostItem->location->street ?? ''); ?>

                                            </small>
                                        <?php else: ?>
                                            <div class="bg-dark rounded d-flex align-items-center justify-content-center" style="height: 150px;">
                                                <small class="text-muted">Нет данных</small>
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    <!-- Блок найденной вещи (проверяем, есть ли она) -->
                                    <div class="col-6">
                                        <strong class="text-white d-block mb-2">Найдено:</strong>
                                        <?php if($match->foundItem): ?>
                                            <?php if($match->foundItem->photo): ?>
                                                <img src="<?php echo e(asset('storage/' . $match->foundItem->photo)); ?>" class="img-fluid rounded mb-2" style="max-height: 150px; object-fit: cover;">
                                            <?php endif; ?>
                                            <p class="mb-1 text-white"><?php echo e($match->foundItem->title); ?></p>
                                            <small class="text-muted">
                                                <?php echo e($match->foundItem->location->city ?? ''); ?>, <?php echo e($match->foundItem->location->street ?? ''); ?>

                                            </small>
                                        <?php else: ?>
                                            <div class="bg-dark rounded d-flex align-items-center justify-content-center" style="height: 150px;">
                                                <small class="text-muted">Чат создан вручную</small>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="mt-auto">
                                    <a href="<?php echo e(route('chat', $match->id)); ?>" class="btn btn-custom-blue w-100 fw-bold">
                                        💬 Перейти в чат
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\findback\resources\views/matches/index.blade.php ENDPATH**/ ?>
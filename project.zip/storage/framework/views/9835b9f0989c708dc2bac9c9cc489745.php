<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center mt-5 mb-5">
        <div class="col-md-9">
            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-outline-secondary mb-3">← Назад</a>

            <div class="card overflow-hidden">
                <div class="row g-0">
                    <div class="col-md-5">
                        <?php if($item->photo): ?>
                            <img src="<?php echo e(asset('storage/' . $item->photo)); ?>" class="img-fluid h-100 w-100" alt="Фото" style="object-fit: cover; min-height: 300px;">
                        <?php else: ?>
                            <div class="bg-secondary d-flex align-items-center justify-content-center h-100" style="min-height: 300px;">
                                <span class="text-muted fs-4">Нет фотографии</span>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-7">
                        <div class="p-4 d-flex flex-column h-100">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h2 class="text-white fw-bold"><?php echo e($item->title); ?></h2>
                                <span class="badge <?php echo e($item->type === 'lost' ? 'bg-danger' : 'bg-success'); ?> fs-6">
                                    <?php echo e($item->type === 'lost' ? 'Потеряно' : 'Найдено'); ?>

                                </span>
                            </div>

                            <h5 class="text-warning mb-4"><?php echo e($item->category->name); ?></h5>

                            <div class="mb-4">
                                <p class="text-light mb-1"><strong>📍 Место:</strong> <?php echo e($item->location->country); ?>, <?php echo e($item->location->city); ?>, <?php echo e($item->location->street); ?></p>
                                <p class="text-light mb-1"><strong>🌳 Точное место:</strong> <?php echo e($item->location->details); ?></p>
                                <p class="text-light mb-1"><strong>📅 Дата:</strong> <?php echo e(\Carbon\Carbon::parse($item->event_date)->format('d.m.Y')); ?></p>
                            </div>

                            <?php if($item->description): ?>
                                <div class="mb-4">
                                    <h6 class="text-white">Описание:</h6>
                                    <p class="text-muted"><?php echo e($item->description); ?></p>
                                </div>
                            <?php endif; ?>

                            <hr class="border-secondary mt-auto">

                            <div class="mt-3">
                                <!-- Ссылка на профиль автора -->
                                <a href="<?php echo e(route('profile.show', $item->user->id)); ?>" class="text-decoration-none">
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white fw-bold me-3" style="width: 50px; height: 50px; font-size: 1.2rem;">
                                            <?php echo e(mb_substr($item->user->name, 0, 1)); ?>

                                        </div>
                                        <div>
                                            <h6 class="text-white mb-0"><?php echo e($item->user->name); ?></h6>
                                            <?php if (isset($component)) { $__componentOriginal68a7f9b685e4c3855325d9cded0a12de = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68a7f9b685e4c3855325d9cded0a12de = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rating-badge','data' => ['rating' => $item->user->rating]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rating-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['rating' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->user->rating)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68a7f9b685e4c3855325d9cded0a12de)): ?>
<?php $attributes = $__attributesOriginal68a7f9b685e4c3855325d9cded0a12de; ?>
<?php unset($__attributesOriginal68a7f9b685e4c3855325d9cded0a12de); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68a7f9b685e4c3855325d9cded0a12de)): ?>
<?php $component = $__componentOriginal68a7f9b685e4c3855325d9cded0a12de; ?>
<?php unset($__componentOriginal68a7f9b685e4c3855325d9cded0a12de); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                </a>

                                <?php if(auth()->guard()->check()): ?>
                                    <?php if(Auth::id() !== $item->user_id && $item->status === 'active'): ?>
                                        <?php if($existingMatch): ?>
                                            <a href="<?php echo e(route('chat', $existingMatch->id)); ?>" class="btn btn-success w-100 py-2 fw-bold">
                                                💬 Перейти в чат (совпадение найдено)
                                            </a>
                                        <?php else: ?>
                                            <form action="<?php echo e(route('chat.start', $item->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-custom-orange w-100 py-2 fw-bold">
                                                    ✉️ Связаться с <?php echo e($item->type === 'lost' ? 'нашедшим' : 'владельцем'); ?>

                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    <?php elseif(Auth::id() === $item->user_id): ?>
                                        <div class="alert alert-secondary text-center py-2 mb-0">Это ваше объявление</div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <a href="<?php echo e(route('login')); ?>" class="btn btn-custom-blue w-100 py-2 fw-bold">Войдите, чтобы связаться</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\findback\resources\views/items/show.blade.php ENDPATH**/ ?>
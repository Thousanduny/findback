<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center mt-4 mb-5">
        <div class="col-md-8">
            <a href="<?php echo e(route('chats.index')); ?>" class="btn btn-outline-secondary mb-3">← Ко всем чатам</a>

            <div class="card overflow-hidden">
                <!-- Шапка чата -->
                <div class="bg-dark p-3 border-bottom border-secondary d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <!-- Аватарка собеседника -->
                        <?php if($opponent && $opponent->avatar): ?>
                            <img src="<?php echo e(asset('storage/' . $opponent->avatar)); ?>" class="rounded-circle me-3" style="width: 40px; height: 40px; object-fit: cover;">
                        <?php else: ?>
                            <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white fw-bold me-3" style="width: 40px; height: 40px; font-size: 1rem;">
                                <?php echo e(mb_substr($opponent->name ?? '?', 0, 1)); ?>

                            </div>
                        <?php endif; ?>

                        <div>
                            <h5 class="text-white mb-0">
                                <a href="<?php echo e($opponent ? route('profile.show', $opponent->id) : '#'); ?>" class="text-white text-decoration-none">
                                    <?php echo e($opponent->name ?? 'Пользователь'); ?>

                                </a>
                            </h5>
                            <?php if($opponent): ?>
                                <?php if (isset($component)) { $__componentOriginal68a7f9b685e4c3855325d9cded0a12de = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68a7f9b685e4c3855325d9cded0a12de = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rating-badge','data' => ['rating' => $opponent->rating]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rating-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['rating' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($opponent->rating)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68a7f9b685e4c3855325d9cded0a12de)): ?>
<?php $attributes = $__attributesOriginal68a7f9b685e4c3855325d9cded0a12de; ?>
<?php unset($__attributesOriginal68a7f9b685e4c3855325d9cded0a12de); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68a7f9b685e4c3855325d9cded0a12de)): ?>
<?php $component = $__componentOriginal68a7f9b685e4c3855325d9cded0a12de; ?>
<?php unset($__componentOriginal68a7f9b685e4c3855325d9cded0a12de); ?>
<?php endif; ?>
                            <?php else: ?>
                                <small class="text-secondary">Рейтинг неизвестен</small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="d-flex align-items-center gap-3">
                        <div class="text-end">
                            <?php if($lostItem): ?> <span class="badge bg-danger mb-1 d-block">Потеряно: <?php echo e($lostItem->title); ?></span> <?php endif; ?>
                            <?php if($foundItem): ?> <span class="badge bg-success d-block">Найдено: <?php echo e($foundItem->title); ?></span> <?php endif; ?>
                        </div>

                        <!-- Кнопка удаления -->
                        <form action="<?php echo e(route('chat.destroy', $match->id)); ?>" method="POST" onsubmit="return confirm('Вы уверены, что хотите удалить этот чат? Все сообщения будут потеряны.');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-outline-danger btn-sm" title="Удалить чат">
                                🗑️
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Окно сообщений -->
                <div class="p-4" style="height: 400px; overflow-y: auto; background-color: #111827;">
                    <?php if($messages->isEmpty()): ?>
                        <div class="text-center text-muted mt-5">
                            <p>Сообщений пока нет. Начните общение!</p>
                        </div>
                    <?php else: ?>
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $isMine = $message->sender_id === Auth::id();
                                $sender = $isMine ? Auth::user() : $opponent;
                            ?>

                            <div class="d-flex mb-3 <?php echo e($isMine ? 'justify-content-end' : 'justify-content-start'); ?>">
                                <?php if(!$isMine): ?>
                                    <?php if($sender && $sender->avatar): ?>
                                        <img src="<?php echo e(asset('storage/' . $sender->avatar)); ?>" class="rounded-circle me-2" style="width: 35px; height: 35px; object-fit: cover;">
                                    <?php else: ?>
                                        <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white fw-bold me-2" style="width: 35px; height: 35px; font-size: 0.9rem;">
                                            <?php echo e(mb_substr($sender->name ?? '?', 0, 1)); ?>

                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <div class="p-2 rounded" style="max-width: 70%; <?php echo e($isMine ? 'background-color: #2563EB; color: white;' : 'background-color: #374151; color: white;'); ?>">
                                    <p class="mb-0"><?php echo e($message->body); ?></p>
                                    <small class="d-block text-end mt-1" style="font-size: 0.7rem; opacity: 0.7;">
                                        <?php echo e($message->created_at->format('H:i')); ?>

                                    </small>
                                </div>

                                <?php if($isMine): ?>
                                    <?php if($sender && $sender->avatar): ?>
                                        <img src="<?php echo e(asset('storage/' . $sender->avatar)); ?>" class="rounded-circle ms-2" style="width: 35px; height: 35px; object-fit: cover;">
                                    <?php else: ?>
                                        <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white fw-bold ms-2" style="width: 35px; height: 35px; font-size: 0.9rem;">
                                            <?php echo e(mb_substr($sender->name ?? '?', 0, 1)); ?>

                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>

                <!-- Форма отправки -->
                <div class="p-3 bg-dark border-top border-secondary">
                    <form action="<?php echo e(route('chat', $match->id)); ?>" method="POST" class="d-flex gap-2">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="body" class="form-control" placeholder="Напишите сообщение..." required autocomplete="off">
                        <button type="submit" class="btn btn-custom-orange px-4">Отправить</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\findback\resources\views/chat/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <!-- Баннер -->
    <div class="hero-graphite text-center mb-5">
        <h1 class="display-4 fw-bold text-white">Потеряй. Найди. Верни.</h1>
        <p class="lead text-light mt-3 mb-5">
            FindBack — это бюро находок, которое работает само.
        </p>
        <div class="d-flex justify-content-center gap-3">
            <a href="<?php echo e(route('items.create')); ?>?type=lost" class="btn btn-custom-orange btn-lg px-5 py-3">Я потерял вещь</a>
            <a href="<?php echo e(route('items.create')); ?>?type=found" class="btn btn-custom-blue btn-lg px-5 py-3">Я нашел вещь</a>
        </div>
    </div>

    <!-- Вкладки и Поиск -->
    <div class="card mb-4 p-4">
        <ul class="nav nav-pills mb-4">
            <li class="nav-item">
                <a class="nav-link <?php echo e(request('type') == '' ? 'active-tab' : 'inactive-tab'); ?>" href="<?php echo e(route('home')); ?>">Все</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request('type') == 'lost' ? 'active-tab' : 'inactive-tab'); ?>" href="<?php echo e(route('home', ['type' => 'lost'])); ?>">Потеряшки</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request('type') == 'found' ? 'active-tab' : 'inactive-tab'); ?>" href="<?php echo e(route('home', ['type' => 'found'])); ?>">Находки</a>
            </li>
        </ul>

        <form action="<?php echo e(route('home')); ?>" method="GET" class="row g-3">
            <input type="hidden" name="type" value="<?php echo e(request('type')); ?>">
            <div class="col-md-4">
                <input type="text" name="search" class="form-control" placeholder="Поиск по названию..." value="<?php echo e(request('search')); ?>">
            </div>
            <div class="col-md-3">
                <input type="text" name="location" class="form-control" placeholder="Город, улица, место..." value="<?php echo e(request('location')); ?>">
            </div>
            <div class="col-md-3">
                <input type="date" name="date" class="form-control" value="<?php echo e(request('date')); ?>">
            </div>
            <div class="col-md-2">
                <select name="sort" class="form-select form-control">
                    <option value="newest" <?php echo e(request('sort') == 'newest' ? 'selected' : ''); ?>>Сначала новые</option>
                    <option value="oldest" <?php echo e(request('sort') == 'oldest' ? 'selected' : ''); ?>>Сначала старые</option>
                </select>
            </div>
            <div class="col-12 text-end">
                <button type="submit" class="btn btn-custom-blue px-4">Найти</button>
                <?php if(request()->anyFilled(['search', 'location', 'date', 'type'])): ?>
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-secondary ms-2">Сбросить</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Лента объявлений -->
    <div class="row mb-5">
        <div class="col-12">
            <?php if($items->isEmpty()): ?>
                <div class="alert alert-secondary">По вашему запросу ничего не найдено.</div>
            <?php else: ?>
                <div class="row">
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 mb-4">
                            <a href="<?php echo e(route('items.show', $item->id)); ?>" class="text-decoration-none">
                                <div class="card h-100">
                                    <?php if($item->photo): ?>
                                        <img src="<?php echo e(asset('storage/' . $item->photo)); ?>" class="card-img-top" alt="Фото" style="height: 180px; object-fit: cover; border-top-left-radius: 12px; border-top-right-radius: 12px;">
                                    <?php else: ?>
                                        <div class="bg-secondary d-flex align-items-center justify-content-center" style="height: 180px; border-top-left-radius: 12px; border-top-right-radius: 12px;">
                                            <span class="text-muted">Нет фото</span>
                                        </div>
                                    <?php endif; ?>

                                    <div class="p-3">
                                        <!-- Название вещи и статус -->
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <h6 class="text-white mb-0"><?php echo e($item->title); ?></h6>
                                            <span class="badge <?php echo e($item->type === 'lost' ? 'bg-danger' : 'bg-success'); ?> ms-2">
                                                <?php echo e($item->type === 'lost' ? 'Потеряно' : 'Найдено'); ?>

                                            </span>
                                        </div>

                                        <!-- Категория -->
                                        <small class="text-muted d-block mb-2"><?php echo e($item->category->name); ?></small>

                                        <!-- Блок с автором (имя сверху, рейтинг снизу) -->
                                        <div class="d-flex flex-column mb-2">
                                            <small class="text-light fw-bold"><?php echo e($item->user->name); ?></small>
                                            <?php if (isset($component)) { $__componentOriginal68a7f9b685e4c3855325d9cded0a12de = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68a7f9b685e4c3855325d9cded0a12de = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rating-badge','data' => ['rating' => $item->user->rating]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rating-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['rating' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->user->rating)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68a7f9b685e4c3855325d9cded0a12de)): ?>
<?php $attributes = $__attributesOriginal68a7f9b685e4c3855325d9cded0a12de; ?>
<?php unset($__attributesOriginal68a7f9b685e4c3855325d9cded0a12de); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68a7f9b685e4c3855325d9cded0a12de)): ?>
<?php $component = $__componentOriginal68a7f9b685e4c3855325d9cded0a12de; ?>
<?php unset($__componentOriginal68a7f9b685e4c3855325d9cded0a12de); ?>
<?php endif; ?>
                                        </div>

                                        <!-- Локация -->
                                        <small class="text-secondary"><?php echo e($item->location->city); ?>, <?php echo e($item->location->street); ?></small>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($items->links('pagination::bootstrap-5')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\findback\resources\views/home/index.blade.php ENDPATH**/ ?>
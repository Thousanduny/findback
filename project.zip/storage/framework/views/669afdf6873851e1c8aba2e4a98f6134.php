<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center mt-4 mb-5">
        <div class="col-md-8">
            <h2 class="text-white mb-4">Мои чаты</h2>

            <?php if($chats->isEmpty()): ?>
                <div class="alert alert-secondary">У вас пока нет активных чатов. Найдите объявление и нажмите «Связаться».</div>
            <?php else: ?>
                <div class="list-group">
                    <?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('chat', $chat['match']->id)); ?>" class="list-group-item list-group-item-action bg-dark text-white border-secondary mb-2 rounded d-flex justify-content-between align-items-center">
                            <div class="d-flex align-items-center">
                                <!-- Аватарка собеседника -->
                                <?php if($chat['opponent'] && $chat['opponent']->avatar): ?>
                                    <img src="<?php echo e(asset('storage/' . $chat['opponent']->avatar)); ?>" class="rounded-circle me-3" style="width: 50px; height: 50px; object-fit: cover;">
                                <?php else: ?>
                                    <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white fw-bold me-3" style="width: 50px; height: 50px; font-size: 1.2rem;">
                                        <?php echo e(mb_substr($chat['opponent']->name ?? '?', 0, 1)); ?>

                                    </div>
                                <?php endif; ?>

                                <div>
                                    <h6 class="mb-0 text-warning"><?php echo e($chat['opponent']->name ?? 'Пользователь'); ?></h6>
                                    <!-- По какому объявлению чат -->
                                    <small class="text-muted">
                                        По объявлению: <span class="text-light"><?php echo e($chat['activeItem']->title ?? 'Неизвестно'); ?></span>
                                        (<?php echo e($chat['activeItem']->type === 'lost' ? 'Потеряно' : 'Найдено'); ?>)
                                    </small>
                                    <!-- Последнее сообщение -->
                                    <?php if($chat['lastMessage']): ?>
                                        <div class="text-secondary text-truncate" style="max-width: 400px; font-size: 0.9rem;">
                                            <?php echo e($chat['lastMessage']->body); ?>

                                        </div>
                                    <?php else: ?>
                                        <div class="text-secondary fst-italic" style="font-size: 0.9rem;">Нет сообщений</div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="text-end">
                                <?php if($chat['lastMessage']): ?>
                                    <small class="text-muted"><?php echo e($chat['lastMessage']->created_at->format('d.m H:i')); ?></small>
                                <?php endif; ?>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\findback\resources\views/chat/index.blade.php ENDPATH**/ ?>
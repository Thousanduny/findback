<?php $__env->startSection('content'); ?>
    <div class="row mt-4">
        <div class="col-12">
            <h2 class="text-white mb-4">Мои объявления</h2>

            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <!-- Вкладки и Поиск -->
            <div class="card mb-4 p-4">
                <ul class="nav nav-pills mb-4">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request('type') == '' ? 'active-tab' : 'inactive-tab'); ?>" href="<?php echo e(route('items.my')); ?>">Все мои</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request('type') == 'lost' ? 'active-tab' : 'inactive-tab'); ?>" href="<?php echo e(route('items.my', ['type' => 'lost'])); ?>">Я потерял</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request('type') == 'found' ? 'active-tab' : 'inactive-tab'); ?>" href="<?php echo e(route('items.my', ['type' => 'found'])); ?>">Я нашел</a>
                    </li>
                </ul>

                <form action="<?php echo e(route('items.my')); ?>" method="GET" class="row g-3">
                    <input type="hidden" name="type" value="<?php echo e(request('type')); ?>">
                    <div class="col-md-4">
                        <input type="text" name="search" class="form-control" placeholder="Поиск по названию..." value="<?php echo e(request('search')); ?>">
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="location" class="form-control" placeholder="Город, улица..." value="<?php echo e(request('location')); ?>">
                    </div>
                    <div class="col-md-3">
                        <input type="date" name="date" class="form-control" value="<?php echo e(request('date')); ?>">
                    </div>
                    <div class="col-md-2">
                        <select name="sort" class="form-select form-control">
                            <option value="newest" <?php echo e(request('sort') == 'newest' ? 'selected' : ''); ?>>Сначала новые</option>
                            <option value="oldest" <?php echo e(request('sort') == 'oldest' ? 'selected' : ''); ?>>Сначала старые</option>
                        </select>
                    </div>
                    <div class="col-12 text-end">
                        <button type="submit" class="btn btn-custom-blue px-4">Найти</button>
                        <?php if(request()->anyFilled(['search', 'location', 'date', 'type'])): ?>
                            <a href="<?php echo e(route('items.my')); ?>" class="btn btn-outline-secondary ms-2">Сбросить</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <!-- Список -->
            <?php if($items->isEmpty()): ?>
                <div class="alert alert-secondary">Объявлений не найдено.</div>
            <?php else: ?>
                <div class="row">
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-3">
                            <div class="card h-100 d-flex flex-column <?php echo e($item->status === 'returned' ? 'opacity-75' : ''); ?>">

                                <!-- ССЫЛКА НА ПРОСМОТР -->
                                <a href="<?php echo e(route('items.show', $item->id)); ?>" class="text-decoration-none">
                                    <?php if($item->photo): ?>
                                        <img src="<?php echo e(asset('storage/' . $item->photo)); ?>" class="card-img-top" alt="Фото" style="height: 200px; object-fit: cover; border-top-left-radius: 12px; border-top-right-radius: 12px;">
                                    <?php endif; ?>

                                    <div class="p-3">
                                        <div class="d-flex justify-content-between mb-2">
                                            <h5 class="text-white"><?php echo e($item->title); ?></h5>
                                            <div>
                                                <span class="badge <?php echo e($item->type === 'lost' ? 'bg-danger' : 'bg-success'); ?> d-block mb-1">
                                                    <?php echo e($item->type === 'lost' ? 'Потеряно' : 'Найдено'); ?>

                                                </span>
                                                <?php if($item->status === 'returned'): ?>
                                                    <span class="badge bg-primary">Возвращено</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <p class="text-muted mb-1">
                                            <?php echo e($item->location->city); ?>, <?php echo e($item->location->street); ?>

                                            <br>
                                            <small>(<?php echo e($item->location->details); ?>)</small>
                                        </p>
                                        <small class="text-secondary mb-2">Дата: <?php echo e(\Carbon\Carbon::parse($item->event_date)->format('d.m.Y')); ?></small>
                                    </div>
                                </a>

                                <!-- Кнопки управления (вне ссылки) -->
                                <div class="px-3 pb-3 mt-auto">
                                    <?php if($item->status === 'active'): ?>
                                        <div class="d-flex gap-2">
                                            <a href="<?php echo e(route('items.edit', $item->id)); ?>" class="btn btn-sm btn-outline-warning w-50">Редактировать</a>

                                            <form action="<?php echo e(route('items.return', $item->id)); ?>" method="POST" class="w-50" onsubmit="return confirm('Вы уверены, что вещь нашлась и вы хотите закрыть объявление?');">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-success w-100">Нашлась!</button>
                                            </form>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($items->links('pagination::bootstrap-5')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\findback\resources\views/items/my.blade.php ENDPATH**/ ?>